package com.br.classes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Projeto {

    private Integer id;
    private String titulo;
    private String resumo;
    private Area area;
    private LocalDate dataEnvio;
    private List<Candidato> candidatos = new ArrayList();
    private Premiacao premiacao;
    private ProjetoAvaliado avaliado;

    public Projeto(Integer id, String titulo, String resumo, Area area, LocalDate dataEnvio, List<Candidato> candidatos, Premiacao premiacao, ProjetoAvaliado avaliado) {
        this.id=id;
        this.titulo=titulo;
        this.resumo=resumo;
        this.area=area;
        this.dataEnvio=dataEnvio;
        this.candidatos=candidatos;
        this.premiacao=premiacao;
        this.avaliado=avaliado;
    }
    
    public void addCandidatoList(List projetos){
        candidatos.add(new Candidato(projetos));
    }

    // <editor-fold defaultstate="collapsed" desc="Sets e Gets para abrir cliquei no +">
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getResumo() {
        return resumo;
    }

    public void setResumo(String resumo) {
        this.resumo = resumo;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public LocalDate getDataEnvio() {
        return dataEnvio;
    }

    public void setDataEnvio(LocalDate dataEnvio) {
        this.dataEnvio = dataEnvio;
    }

    public List<Candidato> getCandidatos() {
        return candidatos;
    }

    public void setCandidatos(List<Candidato> candidatos) {
        this.candidatos = candidatos;
    }

    public Premiacao getPremiacao() {
        return premiacao;
    }

    public void setPremiacao(Premiacao premiacao) {
        this.premiacao = premiacao;
    }

    public ProjetoAvaliado getAvaliado() {
        return avaliado;
    }

    public void setAvaliado(ProjetoAvaliado avaliado) {
        this.avaliado = avaliado;
    }
    
    // </editor-fold> 
}
