package com.br.classes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Comissao {
    private Integer id;
    private String descricao;
    private List<Avaliador> avaliadores = new ArrayList();
    private List<ProjetoAvaliado> projetosAvaliados = new ArrayList();
    
    public void addAvaliadorList(Comissao comissao){
        avaliadores.add(new Avaliador(comissao));
    }
    
    public void addProjetosAvaliados(Integer id, double nota, String justificativa, LocalDate dataEnvio){
        projetosAvaliados.add(new ProjetoAvaliado(id, nota, justificativa, dataEnvio));
    }
    
    // <editor-fold defaultstate="collapsed" desc="Sets e Gets para abrir cliquei no +">

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public List<Avaliador> getAvaliadores() {
        return avaliadores;
    }

    public void setAvaliadores(List<Avaliador> avaliadores) {
        this.avaliadores = avaliadores;
    }

    public List<ProjetoAvaliado> getProjetos() {
        return projetosAvaliados;
    }

    public void setProjetos(List<ProjetoAvaliado> projetoAvaliado) {
        this.projetosAvaliados = projetoAvaliado;
    }
// </editor-fold>    
    
    
}
