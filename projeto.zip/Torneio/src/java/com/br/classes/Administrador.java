package com.br.classes;

public class Administrador extends Usuario{
    
}
