package com.br.classes;

import java.util.ArrayList;
import java.util.List;

public class Estado {
    private Integer id;
    private String uf;
    private List<Cidade> cidades = new ArrayList();
    
    public void addCidadeList(Integer id, String nome, Estado estado){
        cidades.add(new Cidade(id,nome,estado));
    }
    
    // <editor-fold defaultstate="collapsed" desc="Sets e Gets para abrir cliquei no +">
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public List<Cidade> getCidades() {
        return cidades;
    }

    public void setCidades(List<Cidade> cidades) {
        this.cidades = cidades;
    }
    
    // </editor-fold>
    
}
