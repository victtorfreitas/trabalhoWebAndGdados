package com.br.classes;

import java.util.ArrayList;
import java.util.List;

public class Candidato extends Usuario{
    private List<Projeto> projetos = new ArrayList();
    
    public Candidato(List projetos){
        this.projetos=projetos;
    }

    public List<Projeto> getProjetos() {
        return projetos;
    }

    public void setProjetos(List<Projeto> projetos) {
        this.projetos = projetos;
    }
    
}
