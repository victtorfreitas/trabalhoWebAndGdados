package com.br.classes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Area {
    private Integer id;
    private String nome;
    private String descricao;
    private List<Projeto> projetos = new ArrayList();

    public void addProjetoList(Integer id, String titulo, String resumo, Area area, LocalDate dataEnvio, List<Candidato> candidatos, Premiacao premiacao, ProjetoAvaliado avaliado){
        projetos.add(new Projeto(id, titulo, resumo, area, dataEnvio, candidatos, premiacao, avaliado));
    }
    // <editor-fold defaultstate="collapsed" desc="Sets e Gets para abrir cliquei no +">

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public List<Projeto> getProjetos() {
        return projetos;
    }

    public void setProjetos(List<Projeto> projetos) {
        this.projetos = projetos;
    }
    // </editor-fold>
    
}
