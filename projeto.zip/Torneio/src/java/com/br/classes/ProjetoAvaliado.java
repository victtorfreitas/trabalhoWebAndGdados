package com.br.classes;

import java.time.LocalDate;

public class ProjetoAvaliado {
    private Integer id;
    private double nota;
    private String justificativa;
    private LocalDate dataEnvio;

    public ProjetoAvaliado(Integer id, double nota, String justificativa, LocalDate dataEnvio){
        this.id=id;
        this.nota=nota;
        this.justificativa=justificativa;
        this.dataEnvio=dataEnvio;
    }
    
    // <editor-fold defaultstate="collapsed" desc="Sets e Gets para abrir cliquei no +">
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getJustificativa() {
        return justificativa;
    }

    public void setJustificativa(String justificativa) {
        this.justificativa = justificativa;
    }

      public LocalDate getDataEnvio() {
        return dataEnvio;
    }

    public void setDataEnvio(LocalDate dataEnvio) {
        this.dataEnvio = dataEnvio;
    }
    
    // </editor-fold>

  
}
