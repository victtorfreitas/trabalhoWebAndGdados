package com.br.classes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public abstract class Usuario {

    private Integer id;
    private String nome;
    private String cpf;
    private String email;
    private String nascionalidade;
    private String naturalidade;
    private boolean sexo;
    private Rg rg;
    private String senha;
    private boolean ativo;
    private LocalDate nascimento;
    private List<Endereco> enderecos = new ArrayList();
    private List<Telefone> telefones = new ArrayList();

    public void addEnderecoList(String cep, String numero, String tipoLogradouro, String logradouro, String bairro, String complemento, Cidade cidade) {
        enderecos.add(new Endereco(cep, numero, tipoLogradouro, logradouro, bairro, complemento, cidade));
    }

    public void addTelefoneList(String ddd, String numero, String tipo) {
        telefones.add(new Telefone(ddd, numero, tipo));
    }

    // <editor-fold defaultstate="collapsed" desc="Sets e Gets para abrir cliquei no +">
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNascionalidade() {
        return nascionalidade;
    }

    public void setNascionalidade(String nascionalidade) {
        this.nascionalidade = nascionalidade;
    }

    public String getNaturalidade() {
        return naturalidade;
    }

    public void setNaturalidade(String naturalidade) {
        this.naturalidade = naturalidade;
    }

    public boolean isSexo() {
        return sexo;
    }

    public void setSexo(boolean sexo) {
        this.sexo = sexo;
    }

    public Rg getRg() {
        return rg;
    }

    public void setRg(Rg rg) {
        this.rg = rg;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public LocalDate getNascimento() {
        return nascimento;
    }

    public void setNascimento(LocalDate nascimento) {
        this.nascimento = nascimento;
    }

    public List<Endereco> getEnderecos() {
        return enderecos;
    }

    public void setEnderecos(List<Endereco> enderecos) {
        this.enderecos = enderecos;
    }

    public List<Telefone> getTelefones() {
        return telefones;
    }

    public void setTelefones(List<Telefone> telefones) {
        this.telefones = telefones;
    }
    // </editor-fold>
}
