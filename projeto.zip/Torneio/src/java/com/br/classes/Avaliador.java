package com.br.classes;

public class Avaliador extends Usuario {
    private Comissao comissao;

    public Avaliador(Comissao comissao){
        this.comissao = comissao;
    }
    // <editor-fold defaultstate="collapsed" desc="Sets e Gets para abrir cliquei no +">
    public Comissao getComissao() {
        return comissao;
    }

    public void setComissao(Comissao comissao) {
        this.comissao = comissao;
    }
    // </editor-fold>

}
