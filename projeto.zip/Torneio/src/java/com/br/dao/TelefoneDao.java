package com.br.dao;

import com.br.dao.interfaces.InterfaceDependente;
import com.br.classes.Telefone;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TelefoneDao implements InterfaceDependente<Telefone>{

    @Override
    public boolean inserir(Telefone telefone, Integer userID, Connection con) {
        String sql = "insert into telefone (ddd,numero,tipo,usuario_id) values (?,?,?,?)";
        try {
            PreparedStatement ppStatement = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ppStatement.setString(1, telefone.getDdd());
            ppStatement.setString(2, telefone.getNumero());
            ppStatement.setString(3, telefone.getTipo());
            ppStatement.setInt(4, userID);

            ppStatement.executeUpdate();
            
            ResultSet rsKey = ppStatement.getGeneratedKeys();
            if (rsKey.next()) {
                telefone.setId(rsKey.getInt(1));
            }
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(TelefoneDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean alterar(Telefone t, Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean remover(Integer id, Connection con) {
        String sql = "delete from telefone where id = ?;";
        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, id);

            ppStatement.execute();
            ppStatement.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(TelefoneDao.class.getName()).log(Level.ALL, null, ex);
        }
        return false;
    }

    @Override
    public Telefone listar(Integer id, Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Telefone> todos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
