package com.br.dao;

import com.br.classes.Endereco;
import com.br.dao.interfaces.InterfaceDependente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EnderecoDao implements InterfaceDependente<Endereco> {

    @Override
    public boolean inserir(Endereco endereco, Integer userID, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo inserir Endereço para abrir clique no +">
        String sql = "insert into endereco (cep,numero,tipo_logradouro,logradouro,bairro,complemento,usuario_id,cidade_id) values (?,?,?,?,?,?,?,?)";
        try {

            PreparedStatement ppStatement = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ppStatement.setString(1, endereco.getCep());
            ppStatement.setString(2, endereco.getNumero());
            ppStatement.setString(3, endereco.getTipoLogradouro());
            ppStatement.setString(4, endereco.getLogradouro());
            ppStatement.setString(5, endereco.getBairro());
            ppStatement.setString(6, endereco.getComplemento());
            ppStatement.setInt(7, userID);
            ppStatement.setInt(8, endereco.getCidade().getId());

            ppStatement.executeUpdate();

            ResultSet rsKey = ppStatement.getGeneratedKeys();
            if (rsKey.next()) {
                endereco.setId(rsKey.getInt(1));
            }
            ppStatement.close();
            rsKey.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(EnderecoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        // </editor-fold>
    }

    @Override
    public boolean alterar(Endereco t, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo alterar Endereço para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

    @Override
    public boolean remover(Integer id, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo Remover Endereço para abrir clique no +">
        String sql = "delete from endereco where id=?;";
        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, id);
            ppStatement.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(EnderecoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        // </editor-fold>
    }

    @Override
    public Endereco listar(Integer id, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo Listar Endereços por ID para abrir clique no +">

        Endereco endereco = new Endereco();
        CidadeDao cidadeDao = new CidadeDao();
        String sql = "select * from endereco where id=?;";

        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, id);

            ResultSet rs = ppStatement.executeQuery();
            if (rs.next()) {
                endereco.setId(rs.getInt("id"));
                endereco.setCep(rs.getString("cep"));
                endereco.setNumero(rs.getString("numero"));
                endereco.setTipoLogradouro(rs.getString("tipo_logradouro"));
                endereco.setLogradouro(rs.getString("logradouro"));
                endereco.setBairro(rs.getString("bairro"));
                endereco.setComplemento(rs.getString("complemento"));
                endereco.setCidade(cidadeDao.listar(rs.getInt("cidade_id"), con));

            }
            ppStatement.close();
            rs.close();
            return endereco;

        } catch (SQLException ex) {
            Logger.getLogger(EstadoDao.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
        return endereco;
        // </editor-fold>
    }

    @Override
    public List<Endereco> todos() {
        // <editor-fold defaultstate="collapsed" desc="Codigo Listar Todos Endereços para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }
}
