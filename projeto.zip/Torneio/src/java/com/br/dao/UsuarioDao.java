package com.br.dao;

import com.br.classes.Usuario;
import com.br.dao.interfaces.InterfaceIndependente;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsuarioDao implements InterfaceIndependente<Usuario> {

    @Override
    public boolean inserir(Usuario usuario, Connection con) {

        String sql = "insert into usuario (nome,cpf,email,sexo,nascionalidade,naturalidade,nascimento,senha,ativo) values (?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ppStatement = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ppStatement.setString(1, usuario.getNome());
            ppStatement.setString(2, usuario.getCpf());
            ppStatement.setString(3, usuario.getEmail());
            ppStatement.setBoolean(4, usuario.isSexo());
            ppStatement.setString(5, usuario.getNascionalidade());
            ppStatement.setString(6, usuario.getNaturalidade());
            ppStatement.setDate(7, Date.valueOf(usuario.getNascimento()));
            ppStatement.setString(8, usuario.getSenha());
            ppStatement.setBoolean(9, usuario.isAtivo());

            ppStatement.executeUpdate();
            ResultSet rsKey = ppStatement.getGeneratedKeys();
            //Seta o usuario id
            if (rsKey.next()) {
                usuario.setId(rsKey.getInt(1));
            }
            /*Insere o rg dentro do usuario e seta seu id*/
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(EnderecoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean alterar(Usuario t, Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean remover(Integer userID, Connection con) {
        String sql = "delete from usuario where id=?;";
        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, userID);
            ppStatement.executeUpdate();
            ppStatement.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDao.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    public Usuario listar(Usuario user, Connection con) {
        String sql = "select * from usuario where id=?;";

        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, user.getId());

            ResultSet rs = ppStatement.executeQuery(sql);
            if (rs.next()) {
                user.setId(rs.getInt("id"));
                user.setNome(rs.getString("nome"));
                user.setCpf(rs.getString("cpf"));
                user.setEmail(rs.getString("email"));
                user.setSexo(rs.getBoolean("sexo"));
                user.setNascionalidade(rs.getString("nascionalidade"));
                user.setNaturalidade(rs.getString("naturalidade"));
                user.setNascimento(rs.getDate("nascimento").toLocalDate());
                //user.setRg(rs.getString("nome"));
//                user.setLogin(rs.getString("nome"));

            }

            return user;
        } catch (SQLException ex) {
            Logger.getLogger(EstadoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return user;
    }

    @Override
    public List<Usuario> todos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Usuario listar(Integer id, Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
