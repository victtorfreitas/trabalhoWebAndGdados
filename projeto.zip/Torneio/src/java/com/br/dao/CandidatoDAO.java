package com.br.dao;

import com.br.dao.interfaces.InterfaceIndependente;
import com.br.classes.Candidato;
import com.br.classes.Endereco;
import com.br.classes.Telefone;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CandidatoDAO implements InterfaceIndependente<Candidato> {

    @Override
    public boolean inserir(Candidato candidato, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo inserir para abrir clique no +">

        /*Insere o candidato dentro do perfil de usuario e seta seu id*/
        if (!(new UsuarioDao().inserir(candidato, con))) {
            return false;
        }
        System.out.println("usuario OK");
        /*Insere o candidato dentro do perfil de usuario e seta seu id*/
        if (!(new RgDao().inserir(candidato.getRg(), candidato.getId(), con))) {
            return false;
        }
        System.out.println("RG OK");
        /*Percorre a lista adicionando cada elemento dentro do banco e setando o mesmo id na fk*/
        for (Telefone telefone : candidato.getTelefones()) {
            if (!(new TelefoneDao().inserir(telefone, candidato.getId(), con))) {
                return false;
            }
            System.out.println("Telefone ok");
        }
        /*Percorre a lista adicionando cada elemento dentro do banco e setando o mesmo id na fk*/
        for (Endereco endereco : candidato.getEnderecos()) {
            if (!(new EnderecoDao().inserir(endereco, candidato.getId(), con))) {
                return false;
            }
            System.out.println("Endereco ok");
        }

        String sql = "insert into candidato (usuario_id) values (?)";
        try {

            PreparedStatement ppStatement = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ppStatement.setInt(1, candidato.getId());

            ppStatement.executeUpdate();

            ResultSet rsKey = ppStatement.getGeneratedKeys();
            if (rsKey.next()) {
                candidato.setId(rsKey.getInt(1));
            }
            con.commit();

            ppStatement.close();
            rsKey.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(CandidatoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(CandidatoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return false;
        // </editor-fold>
    }

    @Override
    public boolean alterar(Candidato can, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo alterar para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

    @Override
    public boolean remover(Integer id, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo Remover para abrir clique no +">
        return false;
        // </editor-fold>
    }

    @Override
    public Candidato listar(Integer id, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo Listar por ID para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

    @Override
    public List<Candidato> todos() {
        // <editor-fold defaultstate="collapsed" desc="Codigo Listar Todos para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

}
