package com.br.dao;

import com.br.classes.Estado;
import com.br.dao.interfaces.InterfaceIndependente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EstadoDao implements InterfaceIndependente<Estado> {

    @Override
    public boolean inserir(Estado t, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo inserir Estado para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

    @Override
    public boolean alterar(Estado t, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo alterar Estado para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

    @Override
    public boolean remover(Integer id, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo Remover Estado para abrir clique no +">
        String sql = "delete from estado where id=?;";
        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, id);
            ppStatement.executeUpdate();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(EstadoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        // </editor-fold>
    }

    @Override
    public Estado listar(Integer id, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo Listar Estado por ID para abrir clique no +">

        Estado estado = new Estado();
        String sql = "select * from estado where id=?;";

        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, id);

            ResultSet rs = ppStatement.executeQuery();
            if (rs.next()) {
                estado.setId(rs.getInt("id"));
                estado.setUf(rs.getString("uf"));
            }
            ppStatement.close();
            rs.close();
            return estado;
        } catch (SQLException ex) {
            Logger.getLogger(EstadoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return estado;
        // </editor-fold>
    }

    @Override
    public List<Estado> todos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
