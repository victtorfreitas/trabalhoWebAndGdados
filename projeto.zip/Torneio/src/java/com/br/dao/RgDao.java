package com.br.dao;

import com.br.classes.Rg;
import com.br.dao.interfaces.InterfaceDependente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RgDao implements InterfaceDependente<Rg> {
    
    @Override
    public boolean inserir(Rg rg,Integer idUser, Connection con) {
        String sql = "insert into rg (numero,orgao_emissor,estado_id,usuario_id) values (?,?,?,?);";
        try {

            PreparedStatement ppStatement = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ppStatement.setString(1, rg.getNumero());
            ppStatement.setString(2, rg.getOrgaoEmissor());
            ppStatement.setInt(3, rg.getEstado().getId());
            ppStatement.setInt(4, idUser);
            ppStatement.executeUpdate();
            ResultSet rsKey = ppStatement.getGeneratedKeys();

            if (rsKey.next()) {
                rg.setId(rsKey.getInt(1));
            }
            rsKey.close();
            ppStatement.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RgDao.class.getName()).log(Level.ALL, null, ex);
        }
        return false;
    }

    @Override
    public boolean alterar(Rg t, Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean remover(Integer id, Connection con) {
        String sql = "delete from rg where id = ?;";
        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, id);

            ppStatement.execute();
            ppStatement.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(RgDao.class.getName()).log(Level.ALL, null, ex);
        }
        return false;
    }

    @Override
    public Rg listar(Integer id, Connection con) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Rg> todos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
