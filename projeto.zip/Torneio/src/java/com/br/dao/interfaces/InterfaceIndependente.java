package com.br.dao.interfaces;

import java.sql.Connection;
import java.util.List;
/**
 * 
 * @author Gmail
 * @param <T> 
 */
public interface InterfaceIndependente <T>{
    public boolean inserir(T t, Connection con);
    public boolean alterar(T t, Connection con);
    public boolean remover(Integer id, Connection con);
    public T listar(Integer id, Connection con);
    public List<T> todos();
}
