package com.br.dao;

import com.br.dao.interfaces.InterfaceIndependente;
import com.br.classes.Cidade;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CidadeDao implements InterfaceIndependente<Cidade> {

    @Override
    public Cidade listar(Integer id, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo Listar cidade por ID para abrir clique no +">
        Cidade cidade = new Cidade();
        String sql = "select * from cidade where id=?;";

        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, id);

            ResultSet rs = ppStatement.executeQuery();
            if (rs.next()) {
                cidade.setId(rs.getInt("id"));
                cidade.setNome(rs.getString("nome"));
                cidade.setEstado(new EstadoDao().listar(rs.getInt("estado_id"), con));
            }
            ppStatement.close();
            rs.close();
            return cidade;
        } catch (SQLException ex) {
            Logger.getLogger(EstadoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cidade;
        // </editor-fold>
    }

    @Override
    public boolean inserir(Cidade t, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo inserir Cidade para abrir clique no +">

        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

    @Override
    public boolean alterar(Cidade t, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo alterar cidade para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

    @Override
    public boolean remover(Integer id, Connection con) {
        // <editor-fold defaultstate="collapsed" desc="Codigo remover cidade por ID para abrir clique no +">
        String sql = "delete from cidade where id=?;";
        try {
            PreparedStatement ppStatement = con.prepareStatement(sql);
            ppStatement.setInt(1, id);
            ppStatement.executeUpdate();
            ppStatement.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(CidadeDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        // </editor-fold>
    }

    @Override
    public List<Cidade> todos() {
        // <editor-fold defaultstate="collapsed" desc="Codigo Listar Todas Cidades para abrir clique no +">
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        // </editor-fold>
    }

}
