/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aluno
 */
public class ConexaoPost {

    public static void main(String[] args) {

        //testar se conexão funcionou!
        System.out.println(postConnect(false));

    }

    @SuppressWarnings("null")
    public static Connection postConnect(boolean value) {
        String driver = "org.postgresql.Driver";
        String url = "jdbc:postgresql://localhost:5432/banco";
        String name = "postgres";
        String senha = "freitas123";
        Connection con = null;

        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, name, senha);
            con.setAutoCommit(value);

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ConexaoPost.class.getName()).log(Level.SEVERE, null, ex);
        }

        return con;
    }
}
