package Testes;

import com.br.classes.Candidato;
import com.br.classes.Cidade;

import com.br.classes.Estado;
import com.br.classes.Rg;
import com.br.dao.CandidatoDAO;
import com.br.dao.CidadeDao;
import com.br.dao.EstadoDao;
import com.br.dao.UsuarioDao;
import com.br.jdbc.ConexaoPost;
import java.sql.Connection;
import java.time.LocalDate;

public class Principal {

    public static void main(String[] args) {
//        inserir();
//        removerID();
    }

    public static void inserir() {
        Connection con = ConexaoPost.postConnect(false);
        Candidato can = new Candidato(null);
        Estado estado = new EstadoDao().listar(1, con);
        LocalDate nascimento = LocalDate.of(1995, 11, 21);
        Cidade cidade = new CidadeDao().listar(1, con);

        Rg rg = new Rg();
        can.setNome("victtor");
        can.setCpf("0277999212");
        can.setEmail("victtor@victtor");
        can.setSexo(true);
        can.setNascionalidade("brasileiro");
        can.setNaturalidade("Guarai");
        rg.setNumero("982.342");
        rg.setOrgaoEmissor("SSP");
        rg.setEstado(estado);
        can.setRg(rg);
        can.setSenha("123");
        can.setAtivo(true);
        can.setNascimento(nascimento);
        can.addTelefoneList("063", "999888", "fixo");

        can.addEnderecoList("77006404", "27", "qd", "404 norte", "PDN", "SEM", cidade);

        if (new CandidatoDAO().inserir(can, con)) {
            System.out.println("Funcionou");
        }
    }

    public static void removerID() {
        Connection con = ConexaoPost.postConnect(true);
        if (new UsuarioDao().remover(16, con)) {
            System.out.println("Removido");
        }
    }
}
